#!/system/bin/sh
chmod 755 /data/adb/modules/kernelsu-fps/service.sh
